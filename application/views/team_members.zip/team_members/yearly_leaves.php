<table id="yearly-leaves-table" class="display" cellspacing="0" width="100%">            
</table>
<script type="text/javascript">
    $(document).ready(function() {
        loadMembersLeavesTable("#yearly-leaves-table", "yearly");
    });
</script>