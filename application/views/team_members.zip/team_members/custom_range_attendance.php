<table id="custom-range-attendance-table" class="display" cellspacing="0" width="100%">            
</table>
<script type="text/javascript">
    $(document).ready(function () {
        loadMembersAttendanceTable("#custom-range-attendance-table", "custom_range");
    });
</script>